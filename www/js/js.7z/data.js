var data = function( ) {
var lines=null; //, linesBak=[];
var swCallAjax=true;
// http://www.mambiente.munimadrid.es/opencms/export/sites/default/calaire/Anexos/INTPHORA-DIA.pdf
var estaciones={"28079001": "Pº. Recoletos", "28079002": "Glta. de Carlos V", "28079003": "Pza. del Carmen", "28079035": "Pza. del Carmen", "28079004": "Pza. de España", "28079005": "Barrio del Pilar", "28079039": "Barrio del Pilar", "28079006": "Pza. Dr. Marañón", "28079007": "Pza. M. de Salamanca", "28079008": "Escuelas Aguirre", "28079009": "Pza. Luca de Tena", "28079010": "Cuatro Caminos", "28079038": "Cuatro Caminos", "28079011": "Av. Ramón y Cajal", "28079012": "Pza. Manuel Becerra", "28079013": "Vallecas", "28079040": "Vallecas", "28079014": "Pza. Fdez. Ladreda", "28079015": "Pza. Castilla", "28079016": "Arturo Soria", "28079017": "Villaverde Alto", "28079018": "C/ Farolillo", "28079019": "Huerta Castañeda", "28079020": "Moratalaz", "28079036": "Moratalaz II", "28079021": "Pza. Cristo Rey", "28079022": "Pº. Pontones", "28079023": "Final C/ Alcalá", "28079024": "Casa de Campo", "28079025": "Santa Eugenia", "28079026": "Urb. Embajada (Barajas)", "28079027": "Barajas", "28079047": "Méndez Álvaro", "28079048": "Pº. Castellana Alta", "28079049": "Retiro", "28079050": "Pza. Castilla", "28079054": "Ensanche Vallecas", "28079055": "Urb. Embajada (Barajas)", "28079056": "Pza. Fdez. Ladreda", "28079057": "Sanchinarro", "28079058": "El Pardo", "28079059": "Parque Juan Carlos I", "28079086": "Tres Olivos", "28079060": "Tres Olivos"};
var zonas={"Interior-M30":["28079008","28079048","28079015","28079050","28079011", "28079010", "28079038", "28079004","28079005","28079039","28079003","28079035","28079047","28079049"],
           "Sureste":     ["28079020","28079036","28079013","28079040","28079054"],
		   "Noreste":     ["28079016","28079057","28079026","28079055","28079027","28079086","28079060","28079059"],
		   "Noroeste":    ["28079058","28079024"],
		   "suroeste":    ["28079014","28079056","28079018","28079017"]};
// https://gestiona.madrid.org/azul_internet/html/web/2_3.htm?ESTADO_MENU=2_3
var magnitudes={"01": {name: "Dioxido de Azufre",     abrv:"SO2",   unidad:"µg/m3", mediaHoraria:{limite: 350}, mediaDiaria:{limite: 125}},
				"06": {name: "Monoxido de Carbono",   abrv:"CO",    unidad:"mg/m3", maximaDiaria:{limite: 10}},
				"07": {name: "Monoxido de Nitrogeno", abrv:"NO",    unidad:"µg/m3"},
				"08": {name: "Dioxido de Nitrogeno",  abrv:"NO2",   unidad:"µg/m3", mediaAnual:{limite:40}, mediaHoraria:{limite: 200}},
				"09": {name: "Particulas < 2.5 um",   abrv:"PM2,5", unidad:"µg/m3", mediaAnual:{limite: 25}},
				"10": {name: "Particulas < 10 um",    abrv:"PM10",  unidad:"µg/m3", mediaDiaria:{limite: 50}, mediaAnual:{limite:40}},
				"12": {name: "Oxidos de Nitrogeno",   abrv:"NOx",   unidad:"µg/m3", mediaAnual:{critico: 30}},
				"14": {name: "Ozono Troposférico",    abrv:"O3",    unidad:"µg/m3", maximaDiaria: {objetivo: 120, alerta:240, informacion:180}},
				"20": {name: "Tolueno",               abrv:"TOL",   unidad:"µg/m3"},
				"30": {name: "Benceno",               abrv:"BEN",   unidad:"µg/m3", mediaAnual:{limite:5}},
				"35": {name: "Etilbenceno",           abrv:"EB",    unidad:"µg/m3"},
				"37": {name: "Metaxileno",            abrv:"m-Xil", unidad:"µg/m3"},
				"38": {name: "Paraxileno",            abrv:"PXY",   unidad:"µg/m3"},
				"39": {name: "Ortoxileno",            abrv:"OXY",   unidad:"µg/m3"},
				"42": {name: "Hidrocarburos totales(hexano)", abrv:"TCH", unidad:"mg/m3"},
				"44": {name: "Hidrocarburos no metanicos (hexano)", abrv:"NMHC", unidad:"mg/m3"}};

getLimite = function(magnitud){
	var valor=null;
	if('maximaDiaria' in magnitud) valor=magnitud.maximaDiaria;
	else if('mediaHoraria' in magnitud) valor=magnitud.mediaHoraria;
	else if('mediaDiaria' in magnitud) valor=magnitud.mediaDiaria;
	else if('mediaAnual' in magnitud) valor=magnitud.mediaAnual;
	var limite=-1;
	if(valor!=null && 'limite' in valor) limite=valor.limite;
	else if(valor!=null && 'critico' in valor) limite=valor.critico;
	else if(valor!=null && 'alerta' in valor) limite=valor.alerta;
	else if(valor!=null && 'informacion' in valor) limite=valor.informacion*1.5;
	else if(valor!=null && 'objetivo' in valor) limite=valor.objetivo*2;
	return limite;
}

getLines = function(){
	if(lines!=null) return lines;
	info('callAjax');
	var HttpClient = function() {
		this.get = function(aUrl, aCallback) {
			var httpRq = new XMLHttpRequest();
			httpRq.onerror = function(e){
				aCallback('28,079,059,10,08,02,2018,10,21,00017,V,00012,V,00006,V,00007,V,00004,V,00005,V,00016,V,00019,V,00012,V,00022,V,00014,V,00008,V,00012,V,00005,V,00003,V,00002,V,00001,V,00000,N,00000,N,00000,N,00000,N,00000,N,00000,N,00000,N\n28,079,055,10,02,02,2018,10,21,01.27,V,01.27,V,01.27,V,01.27,V,01.27,V,01.26,V,01.26,V,01.26,V,01.30,V,01.27,V,01.27,V,01.27,V,01.27,V,01.27,V,01.28,V,01.27,V,01.26,V,00000,N,00000,N,00000,N,00000,N,00000,N,00000,N,00000,N\n28,079,004,10,48,02,2018,10,21,000.3,V,000.3,V,000.3,V,000.3,V,000.2,V,000.2,V,000.2,V,000.3,V,000.2,V,000.2,V,000.3,V,000.3,V,000.3,V,000.3,V,000.4,V,000.3,V,00040,V,00020,V,00005,V,00010,V,00008,V,00002,V,00015,V,00000,N');
			};
			httpRq.onreadystatechange = function() {
				//info('onreadystatechange: readyState='+httpRq.readyState+' status='+httpRq.status+' text='+httpRq.responseText);
				if (httpRq.readyState == 4 && httpRq.status == 200)
					aCallback(httpRq.responseText);
			}

			httpRq.open( "GET", aUrl, true );            
			httpRq.setRequestHeader("Content-Type", "text/plain;charset=UTF-8");
			httpRq.setRequestHeader("Access-Control-Allow-Origin", "*");
			httpRq.setRequestHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
			httpRq.setRequestHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
			httpRq.withCredentials = true;
			httpRq.send(  );
			var lastCallAjax = new Date().getTime(); // milliseconds since midnight, January 1, 1970
		}
	}
	var client = new HttpClient();
	client.get('http://www.mambiente.munimadrid.es/opendata/horario.txt', function(response) {
		info(response);
		var linesStr = response.split(/\r?\n/);
		lines.splice(0, lines.length);
		
		for(var i=0; i<linesStr.length; i++){
			var cols=linesStr[i].split(',');
			if(cols.length>9){
				var line={station: cols[0]+cols[1]+cols[2], magnitude:cols[3], tech:cols[4], day:cols[6]+cols[7]+cols[8], values:this.parseValues(cols.slice(9))};
				this.setMaxValue(line);
				lines.push(line);
				//linesBak=lines.slice(); //copy
				info(line.station+' '+line.magnitude+'('+this.getLimite(magnitudes[line.magnitude])+') '+line.day+' '+line.values.length);
			}
		}
	});
	return lines;
}

setMaxValue = function(line){
	var maxValue=-1, minValue=999999999999;
	var maxHour=-1, minHour=-1;
	for(var i=0; i<line.values.length; i++){
		if(line.values[i]>maxValue){maxValue=line.values[i]; maxHour=i;}
		if(line.values[i]<minValue){minValue=line.values[i]; minHour=i;}
	}
	line.maxHour=maxHour;
	line.minHour=minHour;
}

sortAsc = function(lines){
	// Ordena de menor a mayor según su máximo valor en el dia
	var x=lines.sort(function(a, b) {
		var v1 = a.maxHour==-1?-1:a.values[a.maxHour];
		var v2 = b.maxHour==-1?-1:b.values[b.maxHour];
		return v1 - v2;
	});
	info(lines.length+' lines sorted asc');
	return x;
}

filterByZone=function(zoneName, lines){
	var st=zonas[zoneName];
	var result=[];
	if(st!=null && st.length==1){
		for(var i=0; i<st.length; i++){
			var s = st[i];
			for(var j=0; j<lines.length; j++) if(lines[j].station==s) result.push(lines[j]);
		}
	}
	return result;
}

filterByStation = function(inStation, lines){
	var linesInStation=[];
	for(var i=0; i<lines.length; i++) if(lines[i].station==inStation) linesInStation.push(lines[i]);
	return linesInStation;
}

filterByMagnitude = function(inMagnitude, lines){
	var linesInMagnitude=[];
	for(var i=0; i<lines.length; i++) if(lines[i].magnitude==inMagnitude) linesInMagnitude.push(lines[i]);
	info(linesInMagnitude.length+' linesInMagnitude found');
	return linesInMagnitude;
}

getValues = function(lines){
	var values=[];
	for(var i=0; i<lines.length; i++) for(var j=0; j<lines[i].values.length; j++) if(lines[i].values[j]!=-1) values.push(lines[i].values[j]);
	return values;
}

parseValues = function(lista){
	valores=[];
	for(var i=1; i<lista.length; i+=2) valores[valores.length]=lista[i]=='V'?parseFloat(lista[i-1]):-1;
	return valores;
}

maxValue = function(lines){
	var maxValue=-1;
	for(var i=0; i<lines.length; i++){
		var l=lines[i];
		if(l.values[l.maxHour]>maxValue) maxValue=l.values[l.maxHour];
	}
	return maxValue;
}

}

//var myp5 = new p5(sketch, document.getElementById('pieChart'));
