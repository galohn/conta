var sketch = function( p ) {
//var colors = ['blue-green','red','yellow','violet','green','purple','orange','blue'];
// https://sashat.me/2017/01/11/list-of-20-simple-distinct-colors/
//var colors = ['Red','Green','Yellow','Blue','Orange','Purple','Cyan','Magenta','Lime','Pink','Teal','Lavender','Brown','Beige','Maroon','Mint','Olive','Apricot','Navy','Grey','White','Black'];
var colors = ['Orange','Cyan','Teal','Lavender','Brown','Beige','Maroon','Mint','Olive','Apricot','Navy','Grey','White','Black'];
var mouseAngle;
var lines=[], linesBak=[];
var swCallAjax=true;
var swDraw=false;
var border=24;
var type={area:0, line:1, bar:2, pie:3};
var typeChart=type.area;
// http://www.mambiente.munimadrid.es/opencms/export/sites/default/calaire/Anexos/INTPHORA-DIA.pdf
var estaciones={"28079001": "Pº. Recoletos", "28079002": "Glta. de Carlos V", "28079003": "Pza. del Carmen", "28079035": "Pza. del Carmen", "28079004": "Pza. de España", "28079005": "Barrio del Pilar", "28079039": "Barrio del Pilar", "28079006": "Pza. Dr. Marañón", "28079007": "Pza. M. de Salamanca", "28079008": "Escuelas Aguirre", "28079009": "Pza. Luca de Tena", "28079010": "Cuatro Caminos", "28079038": "Cuatro Caminos", "28079011": "Av. Ramón y Cajal", "28079012": "Pza. Manuel Becerra", "28079013": "Vallecas", "28079040": "Vallecas", "28079014": "Pza. Fdez. Ladreda", "28079015": "Pza. Castilla", "28079016": "Arturo Soria", "28079017": "Villaverde Alto", "28079018": "C/ Farolillo", "28079019": "Huerta Castañeda", "28079020": "Moratalaz", "28079036": "Moratalaz II", "28079021": "Pza. Cristo Rey", "28079022": "Pº. Pontones", "28079023": "Final C/ Alcalá", "28079024": "Casa de Campo", "28079025": "Santa Eugenia", "28079026": "Urb. Embajada (Barajas)", "28079027": "Barajas", "28079047": "Méndez Álvaro", "28079048": "Pº. Castellana Alta", "28079049": "Retiro", "28079050": "Pza. Castilla", "28079054": "Ensanche Vallecas", "28079055": "Urb. Embajada (Barajas)", "28079056": "Pza. Fdez. Ladreda", "28079057": "Sanchinarro", "28079058": "El Pardo", "28079059": "Parque Juan Carlos I", "28079086": "Tres Olivos", "28079060": "Tres Olivos"};
var zonas={"Interior-M30":["28079008","28079048","28079015","28079050","28079011", "28079010", "28079038", "28079004","28079005","28079039","28079003","28079035","28079047","28079049"],
           "Sureste":     ["28079020","28079036","28079013","28079040","28079054"],
		   "Noreste":     ["28079016","28079057","28079026","28079055","28079027","28079086","28079060","28079059"],
		   "Noroeste":    ["28079058","28079024"],
		   "suroeste":    ["28079014","28079056","28079018","28079017"]};
// https://gestiona.madrid.org/azul_internet/html/web/2_3.htm?ESTADO_MENU=2_3
var magnitudes={"01": {name: "Dioxido de Azufre",     abrv:"SO2",   unidad:"µg/m3", mediaHoraria:{limite: 350}, mediaDiaria:{limite: 125}},
				"06": {name: "Monoxido de Carbono",   abrv:"CO",    unidad:"mg/m3", maximaDiaria:{limite: 10}},
				"07": {name: "Monoxido de Nitrogeno", abrv:"NO",    unidad:"µg/m3"},
				"08": {name: "Dioxido de Nitrogeno",  abrv:"NO2",   unidad:"µg/m3", mediaAnual:{limite:40}, mediaHoraria:{limite: 200}},
				"09": {name: "Particulas < 2.5 um",   abrv:"PM2,5", unidad:"µg/m3", mediaAnual:{limite: 25}},
				"10": {name: "Particulas < 10 um",    abrv:"PM10",  unidad:"µg/m3", mediaDiaria:{limite: 50}, mediaAnual:{limite:40}},
				"12": {name: "Oxidos de Nitrogeno",   abrv:"NOx",   unidad:"µg/m3", mediaAnual:{critico: 30}},
				"14": {name: "Ozono Troposférico",    abrv:"O3",    unidad:"µg/m3", maximaDiaria: {objetivo: 120, alerta:240, informacion:180}},
				"20": {name: "Tolueno",               abrv:"TOL",   unidad:"µg/m3"},
				"30": {name: "Benceno",               abrv:"BEN",   unidad:"µg/m3", mediaAnual:{limite:5}},
				"35": {name: "Etilbenceno",           abrv:"EB",    unidad:"µg/m3"},
				"37": {name: "Metaxileno",            abrv:"m-Xil", unidad:"µg/m3"},
				"38": {name: "Paraxileno",            abrv:"PXY",   unidad:"µg/m3"},
				"39": {name: "Ortoxileno",            abrv:"OXY",   unidad:"µg/m3"},
				"42": {name: "Hidrocarburos totales(hexano)", abrv:"TCH", unidad:"mg/m3"},
				"44": {name: "Hidrocarburos no metanicos (hexano)", abrv:"NMHC", unidad:"mg/m3"}};


p.setup = function() {
  //var canva=p.createCanvas(screen.width, screen.height/3);
  var canva=p.createCanvas(window.innerWidth, window.innerHeight/3);
  //canva.parent('pieChart');
  p.noStroke();
  //noLoop();  // Run once and stop
}

p.windowResized = function () {
  p.resizeCanvas(window.innerWidth, window.innerHeight/3);
  swDraw=true;
}

p.draw = function() {
	//info('swCallAjax='+swCallAjax+' swDraw='+swDraw+' lines='+lines.length);
	if(swCallAjax) p.callAjax();
	if(swDraw){
		p.background(100);
		//info('2 swCallAjax='+swCallAjax+' swDraw='+swDraw+' lines='+lines.length);
		if(lines.length>0)
			if(type.pie==typeChart) p.drawChart(p.sortAsc(p.getMagnitude('10', lines)).slice(-3));
			else if(type.area==typeChart) p.areaLineChart(lines, true);
			else if(type.line==typeChart) p.areaLineChart(lines, false);
		swDraw=false;
	}
}

p.setArea = function(){ typeChart=type.area; }
p.setLine = function(){ typeChart=type.line; }
p.setBar = function(){ typeChart=type.bar; }
p.setPie = function(){ typeChart=type.pie; }

p.filterByZone=function(zoneName){
	var st=zonas[zoneName];
	if(st!=null && st.length==1){
		for(var i=0; i<st.length; i++){
			var s = st[i];
			for(var j=lines.length-1; j>=0; j--) if(lines[j].station==s) lines.splice(j,1);
		}
	}
}

p.redrawPie = function(){
	info('redraw!');
	swCallAjax=true;
}

p.drawChart = function(lines){
	info('drawing '+lines.length+' values');
	p.pieChart(lines);
	info('drwed');
	swDraw=false;
}
p.getLimite = function(magnitud){
	var valor=null;
	if('maximaDiaria' in magnitud) valor=magnitud.maximaDiaria;
	else if('mediaHoraria' in magnitud) valor=magnitud.mediaHoraria;
	else if('mediaDiaria' in magnitud) valor=magnitud.mediaDiaria;
	else if('mediaAnual' in magnitud) valor=magnitud.mediaAnual;
	var limite=-1;
	if(valor!=null && 'limite' in valor) limite=valor.limite;
	else if(valor!=null && 'critico' in valor) limite=valor.critico;
	else if(valor!=null && 'alerta' in valor) limite=valor.alerta;
	else if(valor!=null && 'informacion' in valor) limite=valor.informacion*1.5;
	else if(valor!=null && 'objetivo' in valor) limite=valor.objetivo*2;
	return limite;
}

p.pieChart = function(data) {
  var diameter = Math.min(p.width, p.height)-border;
  var lastAngle = 0;
  var angles=p.getAngles(data);
  for (var i = 0; i < data.length; i++) {
    var gray = p.map(i, 0, data.length, 0, 255);
	p.fill(colors[i]);
    //fill(getColor(i, data));
	var xy=p.pieCenter();
    s=p.arc(xy.x, xy.y, diameter, diameter, lastAngle, lastAngle+p.radians(angles[i]));
	info(s);
	var angle=lastAngle+p.radians(angles[i])/2;
	var radio_ = diameter/2;
	var x0=xy.x + radio_*p.cos(angle);
	var y0=xy.y + radio_*p.sin(angle);
	var str = estaciones[data[i].station]+'\r\n'+data[i].maxHour+'H ['+(data[i].maxHour==-1?0:data[i].values[data[i].maxHour])+']';
	//str=str.replace(' ','\r\n');
	p.textSize(16);
	if(x0<xy.x) p.textAlign(p.CENTER);
	else p.textAlign(p.LEFT);
	p.fill('white');
	p.text(str, x0 - 1, y0 - 1);
	//p.text(str, x0 + 1, y0 + 1);
	p.fill('red');
	p.text(str, x0, y0);
    lastAngle += p.radians(angles[i]);
  }
}

p.getColor = function(i, data){
	var fll = p.map(i, 0, data.length, 0, 255);
	var fillFocus = p.color(fll, 99, 99, 255);
	var fillNoFocus = p.color(fll, 89, 49, 189);
	return fillFocus;
}

p.pieCenter = function(){ return {x:p.width/2, y:p.height/2};}

p.getAngles = function(lines){
	var sum=0;
	var angles=[]
	for(i=0; i<lines.length; i++) sum+=lines[i].maxHour==-1?0:lines[i].values[lines[i].maxHour];
	for(i=0; i<lines.length; i++) angles[i]=p.map(lines[i].maxHour==-1?0:lines[i].values[lines[i].maxHour], 0,sum,0,360);
	return angles;
}

p.callAjax = function(){
	swCallAjax=false;
	info('callAjax');
	var HttpClient = function() {
		this.get = function(aUrl, aCallback) {
			var httpRq = new XMLHttpRequest();
			httpRq.onerror = function(e){
				aCallback('28,079,059,10,08,02,2018,10,21,00017,V,00012,V,00006,V,00007,V,00004,V,00005,V,00016,V,00019,V,00012,V,00022,V,00014,V,00008,V,00012,V,00005,V,00003,V,00002,V,00001,V,00000,N,00000,N,00000,N,00000,N,00000,N,00000,N,00000,N\n28,079,055,10,02,02,2018,10,21,01.27,V,01.27,V,01.27,V,01.27,V,01.27,V,01.26,V,01.26,V,01.26,V,01.30,V,01.27,V,01.27,V,01.27,V,01.27,V,01.27,V,01.28,V,01.27,V,01.26,V,00000,N,00000,N,00000,N,00000,N,00000,N,00000,N,00000,N\n28,079,004,10,48,02,2018,10,21,000.3,V,000.3,V,000.3,V,000.3,V,000.2,V,000.2,V,000.2,V,000.3,V,000.2,V,000.2,V,000.3,V,000.3,V,000.3,V,000.3,V,000.4,V,000.3,V,00040,V,00020,V,00005,V,00010,V,00008,V,00002,V,00015,V,00000,N');
			};
			httpRq.onreadystatechange = function() {
				//info('onreadystatechange: readyState='+httpRq.readyState+' status='+httpRq.status+' text='+httpRq.responseText);
				if (httpRq.readyState == 4 && httpRq.status == 200)
					aCallback(httpRq.responseText);
			}

			httpRq.open( "GET", aUrl, true );            
			httpRq.setRequestHeader("Content-Type", "text/plain;charset=UTF-8");
			httpRq.setRequestHeader("Access-Control-Allow-Origin", "*");
			httpRq.setRequestHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
			httpRq.setRequestHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
			httpRq.withCredentials = true;
			httpRq.send(  );
			var lastCallAjax = new Date().getTime(); // milliseconds since midnight, January 1, 1970
		}
	}
	var client = new HttpClient();
	client.get('http://www.mambiente.munimadrid.es/opendata/horario.txt', function(response) {
		info(response);
		var linesStr = response.split(/\r?\n/);
		lines.splice(0, lines.length);
		
		for(var i=0; i<linesStr.length; i++){
			var cols=linesStr[i].split(',');
			if(cols.length>9){
				var line={station: cols[0]+cols[1]+cols[2], magnitude:cols[3], tech:cols[4], day:cols[6]+cols[7]+cols[8], values:p.calculateValues(cols.slice(9))};
				p.setMaxValue(line);
				lines.push(line);
				linesBak=lines.slice(); //copy
				info(line.station+' '+line.magnitude+'('+p.getLimite(magnitudes[line.magnitude])+') '+line.day+' '+line.values.length);
			}
		}
		swDraw=true;
	});
}

p.setMaxValue = function(line){
	var maxValue=-1, minValue=999999999999;
	var maxHour=-1, minHour=-1;
	for(var i=0; i<line.values.length; i++){
		if(line.values[i]>maxValue){maxValue=line.values[i]; maxHour=i;}
		if(line.values[i]<minValue){minValue=line.values[i]; minHour=i;}
	}
	line.maxHour=maxHour;
	line.minHour=minHour;
}

p.sortAsc = function(lines){
	var x=lines.sort(function(a, b) {
		var v1 = a.maxHour==-1?-1:a.values[a.maxHour];
		var v2 = b.maxHour==-1?-1:b.values[b.maxHour];
		return v1 - v2;
	});
	info(lines.length+' lines sorted asc');
	return x;
}

p.getStation = function(inStation, lines){
	var linesInStation=[];
	for(var i=0; i<lines.length; i++) if(lines[i].station==inStation) linesInStation.push(lines[i]);
	return linesInStation;
}

p.getMagnitude = function(inMagnitude, lines){
	var linesInMagnitude=[];
	for(var i=0; i<lines.length; i++) if(lines[i].magnitude==inMagnitude) linesInMagnitude.push(lines[i]);
	info(linesInMagnitude.length+' linesInMagnitude found');
	return linesInMagnitude;
}

p.getValues = function(lines){
	var values=[];
	for(var i=0; i<lines.length; i++) for(var j=0; j<lines[i].values.length; j++) if(lines[i].values[j]!=-1) values.push(lines[i].values[j]);
	return values;
}

p.calculateValues = function(lista){
	valores=[];
	for(var i=1; i<lista.length; i+=2) valores[valores.length]=lista[i]=='V'?parseFloat(lista[i-1]):-1;
	return valores;
}

p.barChart = function(){

  var data = [105, 212, 158, 31, 98, 54];
  var width = 200, // canvas width and height
      height = 350,
      margin = 20,
      w = width - 2 * margin, // chart area width and height
      h = height - 2 * margin;
  
  var barWidth =  (h / data.length) * 0.8; // width of bar
  var barMargin = (h / data.length) * 0.2; // margin between two bars
  
  createCanvas(width, height);
  
  textSize(14);
  
  push();
  translate(margin, margin); // ignore margin area
  
  for(var i=0; i<data.length; i++) {
    push();
    fill('steelblue');
    noStroke();
    translate(0, i* (barWidth + barMargin)); // jump to the top right corner of the bar
    rect(0, 0, data[i], barWidth); // draw rect

    fill('#FFF');
    text(data[i], 5, barWidth/2 + 5); // write data

    pop();
  }
  
  pop();

}
p.maxValue = function(lines){
	var maxValue=-1;
	for(var i=0; i<lines.length; i++){
		var l=lines[i];
		if(l.values[l.maxHour]>maxValue) maxValue=l.values[l.maxHour];
	}
	return maxValue;
}
p.areaLineChart = function(lines, isArea){
	var maxValue=p.maxValue(lines);
	var xMin=border;
	var xMax=p.width-border;
	var yMin=p.height-border;
	var yMax=border;
	var labels=[];
	for(var idx=0; idx<lines.length; idx++){
		var line=lines[idx];
		var values=[];
	for(var i=line.values.length-1; i>=0 && line.values[i]==-1; i--) line.values.splice(i,1); // Aqui quitamos las ultimas horas sin valor
	
	values.splice(0);
	for(var i=0; i<line.values.length; i++){
		var yValue = line.values[i]==-1?yMin:p.map(line.values[i], 0, maxValue /*line.values[line.maxHour]*/, yMin, yMax);
		var xValue = p.map(i, 0, line.values.length-1, xMin, xMax);
		//p.vertex(xValue, yValue);
		values.push({x:xValue, y:yValue, value:line.values[i], hour:i});
		
		info(line.values[i]+'=vertex ('+xValue+', '+yValue+') en ('+p.width+', '+p.height+')');
	}
	//p.push();
	p.color('white');
	//
	p.stroke(2);
	let c = p.color(colors[idx]);
	if(lines.length>1) c.setAlpha(128);
	if(isArea) p.fill(c);	else p.noFill();
	p.beginShape();
	p.vertex(xMin, yMin);
	for(var i=0; i<values.length; i++) p.vertex(values[i].x, values[i].y);
	p.vertex(xMax, yMin);
	if(isArea) p.endShape(p.CLOSE);	else p.endShape();
	//p.pop();
	///
	p.textAlign(p.CENTER);
	p.textSize(16);
	p.fill('red');
	//var step=1, size=values.length;
	//while((xMax-xMin)/(border+5) < size){step++;size=size/2;}
	//for(var i=0; i<values.length; i+=step) if(values[i].value!=-1) p.text(values[i].value, values[i].x, values[i].y-1);
	for(var i=0; i<values.length; i++) if(values[i].value!=-1) labels.push({txt: values[i].value, x: values[i].x, y: values[i].y-1});
	}
	// pintamos los labels
	p.textAlign(p.CENTER);
	p.textSize(16);
	p.fill('red');
	p.removeLabels(labels);
	for(var i=0; i<labels.length; i++) p.text(labels[i].txt, labels[i].x, labels[i].y);
	// Pintamos las horas
	p.fill('blue');
	var step=1, size=values.length;
	while((xMax-xMin)/(border+5) < size){step++;size=size/2;}
	for(var i=0; i<values.length; i+=step) p.text(i+'h', values[i].x, yMin+border-5);
}

p.removeLabels = function(labels){
	var bor=border+4;
	for(var i=0; i<labels.length; i++){
		var l1 = labels[i];
		for(var j=labels.length-1; j>i; j--){
			var l2=labels[j];
			if(l2.x-bor <= l1.x && l2.x+bor >=l1.x && l2.y-bor <= l1.y && l2.y+bor >=l1.y) labels.splice(j,1);
		}
	}
}

}

//var myp5 = new p5(sketch, document.getElementById('pieChart'));
